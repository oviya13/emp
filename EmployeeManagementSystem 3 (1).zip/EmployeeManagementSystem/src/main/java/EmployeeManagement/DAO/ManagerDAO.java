package EmployeeManagement.DAO;
import java.sql.*;
public class ManagerDAO {
	static Connection con=DBConnection.connectDB();
	public boolean addLeaves(int leaves,int eid)
	{
		try
		{
			PreparedStatement p=con.prepareStatement("update attendance set No_of_Leaves=? where eid=?");
			p.setInt(1,leaves);
			p.setInt(2,eid);
			p.executeUpdate();
			System.out.println("Leaves updated");
			return true;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Something went Wrong....\nTry again later :)");
			return false;
		}
		
	}
	static double salary;
	static double sal;
	static int leaves;
	public double calculateSalary()
	{
		try
		{
			String q="select No_of_Leaves,sal from attendance where eid=?";
			Statement st=con.createStatement();
			 ResultSet rs=st.executeQuery(q);
			 if(rs.next())
			 {
				 leaves=rs.getInt(1);
				 sal=rs.getDouble(2);
			 }
			 else
			 {
				 System.out.println("No record found");
			 }
		}
			 catch(SQLException e)
				{
					e.printStackTrace();
					System.out.println("Something went Wrong....\nTry again later :)");
					
				}
		int deduct=leaves*800;
		double salary=sal-deduct;
		return salary;
		
		
	}
	public void salary(int eid) {
		try
		{
			 double new_sal=calculateSalary();
			 PreparedStatement p=con.prepareStatement("update attendance set sal=? where eid=?");
			 PreparedStatement p1=con.prepareStatement("update employee set sal=? where eid=?");
			 p.setDouble(1,new_sal);
			 p.setInt(2, eid);
			 p1.setDouble(1,new_sal);
			 p1.setInt(2, eid);
			 p.executeUpdate();
			 p1.executeUpdate();
			 System.out.println("Salary updated succesfully\n");			 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("Something went Wrong....\nTry again later :)");
			
		}
	
		
	}
}

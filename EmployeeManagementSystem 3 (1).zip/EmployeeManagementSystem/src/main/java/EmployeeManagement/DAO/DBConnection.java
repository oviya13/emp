package EmployeeManagement.DAO;

import java.sql.*;


public class DBConnection {
	static Connection con=null;
    public static Connection connectDB() {
       try
       {
    			con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/employee_db", "root", "root");
    			return con;
       }
       catch(Exception e) {
			System.out.println("connection failed");
			return null;
		}
            
    }
    }
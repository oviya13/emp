package EmployeeManagement.DAO;
import EmployeeManagement.Models.*;
import java.sql.*;


public class AdminDAO {
	static Connection con=DBConnection.connectDB();	
	 public boolean createEmployee(Admin emp) {  	
 		try {
 			String sql="insert into employee values(?,?,?,?,?,?,?,?)";
 			Connection con=DBConnection.connectDB();
 			PreparedStatement p = con.prepareStatement(sql);
 			p.setInt(1,emp.getId());
 			p.setString(2, emp.getEname());
 			p.setString(3,emp.getPass() );
 			p.setLong(4, emp.getPhno());
 			p.setString(5, emp.getEmail());
 			p.setString(6, emp.getCity());
 			p.setString(7, emp.getDesg());
 			p.setDouble(8,emp.getSal());
 			p.execute();
 			System.out.println("Employee Created Successfully");
 			System.out.println("\n\n");
 			return true;
 		} catch (SQLException e) {
 			e.printStackTrace();
 			System.out.println("Something went Wrong....\nTry again later :)");
 			return false;
 		}
	    }
	 public boolean show(int eid)
	 {
		 try
		 {
			 String q = "SELECT * FROM employee WHERE eid =?";
			 Connection con=DBConnection.connectDB();
			 PreparedStatement s = con.prepareStatement(q);
			 s.setInt(1, eid);
			 ResultSet rs=s.executeQuery();
			 if(rs.next())
			 {
				 System.out.println("Id: "+rs.getInt(1));
				 System.out.println("Name: "+rs.getString(2));
				 System.out.println("Contact: "+rs.getLong(4));
				 System.out.println("Email: "+rs.getString(5));
				 System.out.println("City: "+rs.getString(6));
				 System.out.println("Designation: "+rs.getString(7));
				 System.out.println("Salary: "+rs.getDouble(8));
				 System.out.println("\n\n");
			 }
			 else
			 {
				 System.out.println("Record Not Found...");
			 }
			 rs.close();
	            s.close();
	            con.close();
			 return true; 
		 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
			 System.out.println("Something went Wrong....\nTry again later :)");
			 return false;
		 }
		 
	 }
	
	 public boolean updateN(int eid,String name)
	 {
		 try
		 {
		 PreparedStatement p = con.prepareStatement("update employee set ename=? where eid = ?");
			p.setString(1, name);
			p.setInt(2, eid);
			p.executeUpdate();
			System.out.println("Name updated Successfully");
			return true;
		 }catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateP(int eid,String pass)
	 {
		 try
		 {
		 PreparedStatement pp = con.prepareStatement("update employee set pass=? where eid = ?");
			pp.setString(1, pass);
			pp.setInt(2, eid);
			pp.executeUpdate();
			 System.out.println("Password updated Successfully");
			 return true;
		 }catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateC(int eid,long phno)
	 {
		 try
		 {
		 PreparedStatement p1 = con.prepareStatement("update employee set phno=? where eid = ?");
			p1.setLong(1, phno);
			p1.setInt(2, eid);
			p1.execute();
			System.out.println("Contact updated Successfully");
			return true;
		 }catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateE(int eid,String email)
	 {
		 try
		 {
		 PreparedStatement p2 = con.prepareStatement("update employee set email=? where eid = ?");
			p2.setString(1, email);
			p2.setInt(2, eid);
			p2.executeUpdate();
			System.out.println("Email updated Successfully");
			return true;
		 }catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateCi(int eid,String city)
	 {
		 try
		 {
		 PreparedStatement p3 = con.prepareStatement("update employee set city=? where eid = ?");
			p3.setString(1,city);
			p3.setInt(2, eid);
			p3.executeUpdate();
			System.out.println("City updated Successfully");
			return true;
		 }catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateD(int eid,String desg)
	 {
		 try
		 {
		 PreparedStatement p4= con.prepareStatement("update employee set desg=? where eid = ?");
			p4.setString(1,desg);
			p4.setInt(2, eid);
			p4.executeUpdate();
			System.out.println("Designation updated Successfully"); 
			return true;
		 }
		 catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateS(int eid,double sal)
	 {
		 try
		 {
		 PreparedStatement p5 = con.prepareStatement("update employee set sal=? where eid = ?");
			p5.setDouble(1, sal);
			p5.setInt(2, eid);
			p5.executeUpdate();
			System.out.println("Salary updated Successfully");
			return true;
		 }
		 catch(SQLException e) {
				e.printStackTrace();
				return false;
		 }
	 }
	 public boolean updateA(String name1,long phno1,String email1,String city1,String desig1,double sal1,int eid)
	{
		 try
		 {
		PreparedStatement p6 = con
				.prepareStatement("update employee set ename=?,phno=?,email=?,city=?,desg=?,sal=? where eid = ?");
		p6.setString(1, name1);
		p6.setLong(2, phno1);
		p6.setString(3, email1);
		p6.setString(4, city1);
		p6.setString(5, desig1);
		p6.setDouble(6, sal1);
		p6.setInt(7, eid);
		p6.executeUpdate();
		System.out.println("Updated Successfully");
		return true;
		 }
		catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	 public  boolean remove(int eid)
	 {
		 
		 try
		 {
			 Connection con=DBConnection.connectDB();
			 PreparedStatement p=con.prepareStatement("delete from employee where eid=?");
			 p.setInt(1, eid);
			 p.execute();
			 System.out.println("Deleted Successfully");
			 return true;
		 }
		 catch(SQLException e)
		 {
			 e.printStackTrace();
			 System.out.println("Something went Wrong....\nTry again later :)");
			 return false;
		 }
	 }
}

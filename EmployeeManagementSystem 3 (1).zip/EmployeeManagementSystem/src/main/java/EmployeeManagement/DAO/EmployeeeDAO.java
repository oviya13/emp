package EmployeeManagement.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmployeeeDAO {
	static Connection con=DBConnection.connectDB();
	public boolean login(int id, String pwd) {
		String sql = "select * from employee where eid = ? and pass = ?;"; 
		try {
			PreparedStatement s = con.prepareStatement(sql);
			s.setInt(1, id);
			s.setString(2, pwd);
			ResultSet rs = s.executeQuery();
			
			return rs.next();
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
}

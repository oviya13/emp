package EmployeeManagement.Services;


import EmployeeManagement.DAO.EmployeeeDAO;
public class EmployeeOperations {
	EmployeeeDAO ed=new EmployeeeDAO();
	public boolean EmpLogin(int id,String pass)
	{
		return ed.login(id, pass);
	}
	
	
}

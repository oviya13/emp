package EmployeeManagement.Services;
import java.util.*;
public class ManagerLogin {
	Scanner sc=new Scanner(System.in);
	public void manager()
	{
		AdminOperations ad=new AdminOperations();
		ManagerOperations md=new ManagerOperations();
	while(true)
	{
	System.out.println("Select an option\n"
			+ "1. Update Employee details\n"
			+ "2. View Employee details\n"
			+ "3. Add Leaves\n"
			+ "4. Update Salary\n"
			+ "5. Exit\n");
	
	int s=sc.nextInt();
	switch(s)
	{
	case 1:
		ad.updateEmployee();
		break;
	case 2:
		ad.viewEmployee();
		break;
	case 3:
		md.updateLeaves();
		break;
	case 4:
		md.updateSalary();
		break;
	case 5:
		System.out.println("Thank you");
		System.exit(0);
	default:
		System.out.println("Select the correct option");
	}
	}
	}
}

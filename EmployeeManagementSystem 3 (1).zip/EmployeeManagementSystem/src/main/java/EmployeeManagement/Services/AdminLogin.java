package EmployeeManagement.Services;
import java.util.*;

import EmployeeManagement.main.Main;
public class AdminLogin {
	Scanner sc=new Scanner(System.in);
	AdminOperations ad=new AdminOperations();
	Main m=new Main();
		public void admin()
		
		{while(true)
    	{
    		System.out.println("Select an option\n"
    				+ "1. Create Employee\n"
    				+ "2. View Employee Details\n"
    				+ "3. Update Employee Details\n"
    				+ "4. Remove Employee\n"
    				+ "5. Exit");
    		int s=sc.nextInt();
    		switch(s)
    		{
    		case 1:
    			ad.addEmployee();
    			break;
    		
    		case 2:
    			ad.viewEmployee();
    			break;
    		case 3:
    			ad.updateEmployee();
    			break;
    		case 4:
    			ad.removeEmployee();
			break;
    		case 5:
    			System.out.println("Thank You");
    		default:
    			System.out.println("Enter valid option");
    		}
    	}
		}
}

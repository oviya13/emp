package EmployeeManagement.Services;

import java.util.*;
import EmployeeManagement.DAO.*;
public class ManagerOperations {
	static Scanner sc=new Scanner(System.in);
	static int leaves;
	static ManagerDAO md=new ManagerDAO();
	EmployeeeDAO ed=new EmployeeeDAO();
	public boolean ManagerLogin(int id,String pass)
	{
		return ed.login(id, pass);
	}
	public void updateLeaves()
	{
		System.out.println("Enter employee id to add No. of Leaves");
		int eid=sc.nextInt();
		System.out.println("Enter the No_of_Leaves");
		leaves=sc.nextInt();
		md.addLeaves(leaves, eid);
	}
	
	public void updateSalary()
	{
		System.out.println("Enter the employee id to update the salary");
		int eid=sc.nextInt();
		md.salary(eid);
	}
	
}

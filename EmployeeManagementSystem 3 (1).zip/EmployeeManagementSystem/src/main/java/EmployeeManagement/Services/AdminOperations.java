package EmployeeManagement.Services;
import EmployeeManagement.Models.*;
import EmployeeManagement.DAO.*;

import java.util.*;

public class AdminOperations {
	Scanner sc=new Scanner(System.in);
	EmployeeeDAO ed=new EmployeeeDAO();
	Validation valid=new Validation();
	public boolean AdminLogin(int id,String pass)
	{
		return ed.login(id, pass);
	}
	public void addEmployee()
	{
	System.out.println("Enter Employee Id:");
	int id=valid.validateIntValues("id");
	System.out.println("enter the employee name:");
	String name=valid.validateString();
	System.out.println("enter the Password:");
	String pass=valid.validatePassword();
	System.out.println("enter the employee phno:");
	long phno=valid.validateLongValues("phno");
	System.out.println("enter the employee email:");
	String email=sc.next();
	System.out.println("enter the employee City:");
	String city=valid.validateString();
	System.out.println("enter the employee Designation:");
	String desg=valid.validateString();
	System.out.println("enter the employee Salary:");
	double sal=sc.nextDouble();
	Admin emp=new Admin(id,name,pass,phno,email,city,desg,sal);
	 
	AdminDAO ad=new AdminDAO();
	ad.createEmployee(emp);
	}
	
	public void viewEmployee()
	{
		System.out.println("Enter the employee id to view the details:");
		 int eid=sc.nextInt();
		 AdminDAO ad=new AdminDAO();
		 ad.show(eid);
	}
	
	public void updateEmployee()
	{
		AdminDAO ad=new AdminDAO();
		System.out.println("Enter the id to update details");
		int eid=sc.nextInt();
	System.out.println("Select an option\n"
			+ "1. Update Employee's Name\n"
			+ "2. Update Account Password\n"
			+ "3. Update Employee's Mobile\n"
			+ "4. Update Employee's Email\n"
			+ "5. Update Employee's City\n"
			+ "6. Update Employee's Designation\n"
			+ "7. Update Employee's Salary\n"
			+ "8. Update all details\n"
			+ "9. Exit");
	int s=sc.nextInt();
	switch(s)
	{
		case 1:
			System.out.println("Enter the New employee name");
			String name=sc.next();
			ad.updateN(eid,name);
			break;
		case 2:
			 System.out.println("Enter the New Password");
			 String pass=sc.next();
			 ad.updateP(eid,pass);
			break;
		case 3:
			System.out.println("Enter the new contact");
			Long phno=sc.nextLong();
			ad.updateC(eid,phno);
			break;
		case 4:
			 System.out.println("Enter the new email");
			 String email=sc.next();
			 ad.updateE(eid, email);
			 break;
		case 5:
			 System.out.println("Enter the new city");
			 String city=sc.next();
			 ad.updateCi(eid, city);
			 break;
		 case 6:
			 System.out.println("Enter the new designation");
			 String desig=sc.next();
			 ad.updateD(eid, desig);
			 break;
		 case 7:
			 System.out.println("Enter the new salary");
			 double sal=sc.nextDouble();
			 ad.updateS(eid, sal);
			 break;
		 case 8:
			 System.out.println("Enter all the details\n"
				 		+ "1. Name, 2. Phno, 3. Email, 4. City, 5.Designation, 6. Salary");
				 String name1=sc.next();
				 Long phno1=sc.nextLong();
				 String email1=sc.next();
				 String city1=sc.next();
				 String desig1=sc.next();
				 double sal1=sc.nextDouble();
				 ad.updateA(name1,phno1,email1,city1, desig1, sal1, eid);
				 break;
		 case 9:
			 System.out.println("Thank you");
			 System.exit(0);
		 default: 
			System.out.println("Enter the correct value");
	}
}
	public void removeEmployee()
	{
		System.out.println("Enter employee id to delete the details");
		int eid=sc.nextInt();
		AdminDAO ad=new AdminDAO();
		ad.remove(eid);
	}
}

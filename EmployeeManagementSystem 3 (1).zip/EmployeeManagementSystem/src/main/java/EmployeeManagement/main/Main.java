package EmployeeManagement.main;
import EmployeeManagement.Services.*;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		ManagerLogin ml=new ManagerLogin();
		AdminLogin al=new AdminLogin();
		AdminOperations ad=new AdminOperations();
		EmployeeOperations el=new EmployeeOperations();
		ManagerOperations md=new ManagerOperations();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Select an option\n"
					+ "1. Admin\n"
					+ "2. Manager\n"
					+ "3. Employee\n"
					+ "4. Exit");
			int s=sc.nextInt();
			switch(s)
			{
			case 1:
				System.out.println("Welcome to Admin login");
				System.out.println("Enter the employee id");
				int eid1=sc.nextInt();
				System.out.println("Enter the password");
				String pwd1=sc.next();
				if(ad.AdminLogin(eid1, pwd1))
				{
					System.out.println("Login Successfull");
					al.admin();
				}
				else
				{
					System.out.println("Login failed");
					ad.AdminLogin(eid1,pwd1);
				}
				break;
			case 2:
				System.out.println("Welcome to Manager login");
				System.out.println("Enter the employee id");
				int eid2=sc.nextInt();
				System.out.println("Enter the password");
				String pwd2=sc.next();
				if(md.ManagerLogin(eid2, pwd2))
				{
					System.out.println("Login Successfull");
					ml.manager();
				}
				else
				{
					System.out.println("Login failed");
					md.ManagerLogin(eid2, pwd2);
				}
				
				break;
			
			case 3:
				System.out.println("Welcome to Employee login");
				System.out.println("Enter the employee id");
				int eid=sc.nextInt();
				System.out.println("Enter the password");
				String pwd=sc.next();
				if(el.EmpLogin(eid, pwd))
				{
					System.out.println("Login Successfull");
					ad.viewEmployee();
				}
				else
				{
					System.out.println("Login failed");
					el.EmpLogin(eid,pwd);
				}
				break;
			case 4:
				System.out.println("Thank you");
				System.exit(0);
			default:
				System.out.println("Select the correct option");
			}
		}
	}

}

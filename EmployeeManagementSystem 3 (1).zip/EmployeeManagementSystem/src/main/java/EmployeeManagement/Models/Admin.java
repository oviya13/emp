package EmployeeManagement.Models;

public class Admin {
	private  String e_name,email,desg,city,pass;
	private  int e_id;
	private	 long phno;
	private double sal;
	
	public String getEname()
	{
		return e_name;
	}
	public void setEname(String e_name)
	{
		this.e_name=e_name;
	}
	
	public String getPass()
	{
		return pass;
	}
	public void setPass(String pass)
	{
		this.pass=pass;
	}
	
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email=email;
	}
	
	public String getDesg()
	{
		return desg;
	}
	public void setDesg(String desg)
	{
		this.desg=desg;
	}
	
	public String getCity()
	{
		return city;
	}
	public void setCity(String city)
	{
		this.city=city;
	}
	
	public int getId()
	{
		return e_id;
	}
	public void setDob(int e_id)
	{
		this.e_id=e_id;
	}
	
	public long getPhno()
	{
		return phno;
	}
	public void setPhno(long phno)
	{
		this.phno=phno;
	}
	
	
	public double getSal()
	{
		return sal;
	}
	public void setSal(double sal)
	{
		this.sal=sal;
	}

	public Admin(int e_id,String e_name,String pass,long phno,String email,String city,String desg,double sal)
	{
		this.e_id=e_id;
		this.e_name=e_name;
		this.pass=pass;
		this.phno=phno;
		this.email=email;
		this.city=city;
		this.desg=desg;
		this.sal=sal;
		
	}

}
